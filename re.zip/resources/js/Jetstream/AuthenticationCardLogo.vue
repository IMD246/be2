<template>
    <inertia-link :href="'/'">
       <img src="{{asset ('images/nlogo.png')}}" width="100" height="100" alt="logo">
    </inertia-link>
</template>
